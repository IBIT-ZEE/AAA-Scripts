Invoke-Expression -Command "c:\apl\!TOOLS\_NETWORK\_REMOTE\TightVNC\tvnserver64.exe -controlservice -connect ibit.dynu.net"
