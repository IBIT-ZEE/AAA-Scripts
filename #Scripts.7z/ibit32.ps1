Invoke-Expression -Command "c:\apl\!TOOLS\_NETWORK\_REMOTE\TightVNC\tvnserver32.exe -controlservice -connect ibit.dynu.net"
