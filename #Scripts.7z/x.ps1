
Param( $x )

$x
$args


AAA-Alert 123


Read-Host -prompt "Enter key..."

